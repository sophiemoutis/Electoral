public class State {

    public State(String value, int parseInt, String value1) {
        statename = value;
        electoralvotecount = parseInt;
        party = value1;
    }

    public static void main(String[] args) {

    }

    public String statename;
    public int electoralvotecount;
    public String party;

    public void setStatename(String s) {
        statename = s;
    }

    public String getStatename() {
        return statename;
    }

    public void setElectoralvotecount(int e) {
        electoralvotecount = e;
    }

    public int getElectoralvotecount() {
        return electoralvotecount;
    }

    public void setParty(String p) {
        party = p;
    }

    public String getParty() {
        return party;
    }
}







