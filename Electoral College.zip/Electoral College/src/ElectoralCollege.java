import java.lang.reflect.Array;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
public class ElectoralCollege {
    public static void main(String[] args) {
        File file = new File("electoral_data(2).csv");
        ArrayList<State> states = new ArrayList<>();
        try {
            Scanner scanner = new Scanner(file);
            scanner.nextLine();
            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                String stateName = data[0];
                int electoralVotes = Integer.parseInt(data[1]);
                String party = data[2];
                State state = new State(stateName, electoralVotes, party);
                states.add(state);
            }
            System.out.println(states.size());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        ArrayList<State> simulationStates = new ArrayList<State>();

        for(State state: states) {

            simulationStates.add(new State(state.getStatename(), state.getElectoralvotecount(), state.getParty()));


        }
        }
    }

